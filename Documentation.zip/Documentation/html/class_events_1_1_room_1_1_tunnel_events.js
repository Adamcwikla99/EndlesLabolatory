var class_events_1_1_room_1_1_tunnel_events =
[
    [ "AwakeRoomEntity", "class_events_1_1_room_1_1_tunnel_events.html#a1a4d7623cbd0ff00cae3ef42a7016872", null ],
    [ "KillAllRoomEntity", "class_events_1_1_room_1_1_tunnel_events.html#a6d1edeb848bdfa5c055055616fcd5b52", null ]
];