var class_events_1_1_menu_1_1_toggle_minimap_event =
[
    [ "ChangeMinimapState", "class_events_1_1_menu_1_1_toggle_minimap_event.html#a056d17b41a9860c2e3ff7710edc235c6", null ],
    [ "ToggleMinimap", "class_events_1_1_menu_1_1_toggle_minimap_event.html#ac73b0a1b24fb896a0ec381f0695a0ab5", null ]
];