var class_events_1_1_u_i_1_1_update_beaten_enemys =
[
    [ "RelayNewBeatenEnemysCount", "class_events_1_1_u_i_1_1_update_beaten_enemys.html#ab71802fa506f44e2ff4208ca270a4309", null ]
];