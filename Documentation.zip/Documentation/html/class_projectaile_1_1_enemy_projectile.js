var class_projectaile_1_1_enemy_projectile =
[
    [ "Fire", "class_projectaile_1_1_enemy_projectile.html#a6c6630ad23ed2449c5f8735d67cecc97", null ],
    [ "OnHit", "class_projectaile_1_1_enemy_projectile.html#af002fac78c74c503524f3951efe6b109", null ],
    [ "SetProjectileParameters", "class_projectaile_1_1_enemy_projectile.html#a8a5f8491ac681a5dafb579c8c1b08cd1", null ]
];