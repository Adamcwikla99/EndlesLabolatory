var class_map_generator_1_1_map_layout_generation_1_1_boss_room_generator =
[
    [ "BossRoomGenerator", "class_map_generator_1_1_map_layout_generation_1_1_boss_room_generator.html#a1e617eff243439ab8be2b7e235cc07c1", null ],
    [ "AddBossRooms", "class_map_generator_1_1_map_layout_generation_1_1_boss_room_generator.html#af78e9c922d0908c7dfe7e2a555ba0d22", null ]
];