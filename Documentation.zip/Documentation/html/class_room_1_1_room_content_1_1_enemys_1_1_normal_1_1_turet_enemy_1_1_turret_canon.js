var class_room_1_1_room_content_1_1_enemys_1_1_normal_1_1_turet_enemy_1_1_turret_canon =
[
    [ "DeflectProjectile", "class_room_1_1_room_content_1_1_enemys_1_1_normal_1_1_turet_enemy_1_1_turret_canon.html#a3550e4e7cacf595428b35733559d274b", null ],
    [ "TakeDamage", "class_room_1_1_room_content_1_1_enemys_1_1_normal_1_1_turet_enemy_1_1_turret_canon.html#af4be69e5d1583677392745675e967f0c", null ]
];