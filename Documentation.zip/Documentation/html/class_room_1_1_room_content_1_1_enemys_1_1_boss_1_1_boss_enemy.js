var class_room_1_1_room_content_1_1_enemys_1_1_boss_1_1_boss_enemy =
[
    [ "PlayFireSound", "class_room_1_1_room_content_1_1_enemys_1_1_boss_1_1_boss_enemy.html#aa2ad5ed2b84aba915d1be3f3b529f12d", null ],
    [ "SetBossRoomController", "class_room_1_1_room_content_1_1_enemys_1_1_boss_1_1_boss_enemy.html#a404f4c6ab8d3087077a0d75873ec7e08", null ],
    [ "TakeDamage", "class_room_1_1_room_content_1_1_enemys_1_1_boss_1_1_boss_enemy.html#a97de17a80c82435429920de53c3d8f1f", null ]
];