var class_events_1_1_game_1_1_game_score =
[
    [ "GetBeatenFloors", "class_events_1_1_game_1_1_game_score.html#a103587097bd3bee33f451598eba8ca8e", null ],
    [ "IncreaseBeatenEnemysCount", "class_events_1_1_game_1_1_game_score.html#a209cc1f49a8e106e193c440f5bfbeda0", null ],
    [ "IncreaseBeatenFloorsCount", "class_events_1_1_game_1_1_game_score.html#adb8898334e6360e017299b2e38666a7f", null ]
];