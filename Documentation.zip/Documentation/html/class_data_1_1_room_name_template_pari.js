var class_data_1_1_room_name_template_pari =
[
    [ "templateFileName", "class_data_1_1_room_name_template_pari.html#a89fc43cf4ffab28197ca26193b6c1dfd", null ],
    [ "templateID", "class_data_1_1_room_name_template_pari.html#ab2cf3f4672bc3c3224c10817d4501c31", null ]
];