var class_events_1_1_player_1_1_player_speed_events =
[
    [ "AddSpeedDown", "class_events_1_1_player_1_1_player_speed_events.html#adc6190664df394a9a9b19527f85c7d4c", null ],
    [ "AddSpeedUp", "class_events_1_1_player_1_1_player_speed_events.html#a87adbe93694c3342f3f8da01466c08d5", null ]
];