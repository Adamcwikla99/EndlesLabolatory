var class_events_1_1_player_1_1_player_stats_events =
[
    [ "AddStat", "class_events_1_1_player_1_1_player_stats_events.html#a88aaf25034ed26441b8327be16520f37", null ],
    [ "GetStat", "class_events_1_1_player_1_1_player_stats_events.html#a6138a17e117fc39db14616fcb83b7886", null ]
];