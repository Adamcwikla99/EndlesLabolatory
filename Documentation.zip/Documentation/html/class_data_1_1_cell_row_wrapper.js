var class_data_1_1_cell_row_wrapper =
[
    [ "CellRowWrapper", "class_data_1_1_cell_row_wrapper.html#a6220cf03e935fd698de71ea0e9cac8f0", null ],
    [ "cells", "class_data_1_1_cell_row_wrapper.html#aab956e03cfd4406e72bdd4d7ff16ee28", null ]
];