var class_events_1_1_u_i_1_1_shop_popup =
[
    [ "PopPopup", "class_events_1_1_u_i_1_1_shop_popup.html#a5816794b3a23fa3e46dfe22e5462c49c", null ],
    [ "TurnOffPopup", "class_events_1_1_u_i_1_1_shop_popup.html#ae24564f1d8f0866a40b4312a36c1f40a", null ]
];