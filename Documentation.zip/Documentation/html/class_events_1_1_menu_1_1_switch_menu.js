var class_events_1_1_menu_1_1_switch_menu =
[
    [ "switchMenu", "class_events_1_1_menu_1_1_switch_menu.html#a3629231b03616ed06fc73814bf56f47e", null ]
];