var class_events_1_1_room_1_1_room_events =
[
    [ "GetRandomRoomGridTemplate", "class_events_1_1_room_1_1_room_events.html#a8c767e4fdc64707069e6101d73ead148", null ],
    [ "GetRoomGridTemplate", "class_events_1_1_room_1_1_room_events.html#a33f0678f9829688ec85c71280082ed7a", null ]
];