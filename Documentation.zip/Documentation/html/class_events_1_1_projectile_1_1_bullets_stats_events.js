var class_events_1_1_projectile_1_1_bullets_stats_events =
[
    [ "DecreaseReload", "class_events_1_1_projectile_1_1_bullets_stats_events.html#a28bd1f0f3eccfcf8c1c1da352611fab9", null ],
    [ "IncreaseDamage", "class_events_1_1_projectile_1_1_bullets_stats_events.html#a2a65aa605b360f08b977a0a9ff87731a", null ],
    [ "IncreaseSpeed", "class_events_1_1_projectile_1_1_bullets_stats_events.html#afccf28b89fd984bac07ecb79a83d75fd", null ]
];