var class_events_1_1_scene_1_1_switch_scene =
[
    [ "RestartGameMap", "class_events_1_1_scene_1_1_switch_scene.html#aaece9455353e3129b1ed8a2bc3c7f40e", null ],
    [ "SwitchCurrentScene", "class_events_1_1_scene_1_1_switch_scene.html#a4c7de7e1e38c360edca3dc06efaf47e3", null ]
];