var class_room_1_1_room_content_1_1_enemys_1_1_normal_1_1_base_enemy_1_1_base_enemy_attack_a_i =
[
    [ "FireAtPlayer", "class_room_1_1_room_content_1_1_enemys_1_1_normal_1_1_base_enemy_1_1_base_enemy_attack_a_i.html#ae0c257185809b85ae1b1163e12e5595a", null ],
    [ "ThisEnemyObject", "class_room_1_1_room_content_1_1_enemys_1_1_normal_1_1_base_enemy_1_1_base_enemy_attack_a_i.html#a79817819e1e2ec89064a0930377590b4", null ]
];